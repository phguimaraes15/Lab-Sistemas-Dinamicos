clc;
close all;
s = tf('s');
p = (s^2 + 2*s + 1);
q = (s + 1);
%%%%%%%%%%%%% A 
G = p*q
%%%%%%%%%%%%% B 
G = q/p
polos = pole(G)
zeros = zero(G)
%%%%%%%%%%%%% C
p = [1 2 1];
q = [1 1];
H = idtf(q,p);
z = -1+j;
evalfr(H, z)
%%%%%%%%%%%%% D 
pzmap(Gs); grid on
