%%%%%%%%%%%%%%%%%% A 
Ds = tf([0,1],[1,0]);
Us = tf([0,1],[1,0]);
Hds = tf([0,2.5],[1,0.5]);
Hus = tf([0,2],[1,0.5]);
Ys = - series(Ds,Hds) + series(Us,Hus)

%%%%%%%%%%%%%%%%%% B
Ds = tf([0,0],[1,0]);
Us = tf([0,1],[5,0]);
Hds = tf([0,2.5],[1,0.5]);
Hus = tf([0,2],[1,0.5]);
Ys = - series(Ds,Hds) + series(Us,Hus)
step(Ys);

%%%%%%%%%%%%%%%%%% C

Ds = tf([0,1],[1,0]);
Us = tf([0,1],[5,0]);
Hds = tf([0,2.5],[1,0.5]);
Hus = tf([0,2],[1,0.5]);
Ys = - series(Ds,Hds) + series(Us,Hus)
step(Ys);

%%%%%%%%%%%%%%%%%% D 
Ds = tf([0,1],[1,0]);
Us = tf([0,1],[5,0]);
Hds = tf([0,2.5],[1,0.5]);
Hus = tf([0,2],[1,0.5]);
ds = tf([0,1],[1,-120]);
Ys = - series(series(Ds,Hds),ds) + series(Us,Hus)
step(Ys);